Odontología module - Integración CSS
Fecha: 2025-09-02

Cambios realizados:
- Añadido archivo assets/css/odontologia.css con estilos globales.
- includes/header.php reescrito para usar un único enlace a Bootstrap y añadir el CSS global.
- Eliminados bloques <style> embebidos en archivos .php para evitar conflictos.
- Archivos con <head> propios (index.php, login.php) ahora cargan el CSS en su <head> si no usaban includes/header.php.

Ruta del CSS: /odontologia/assets/css/odontologia.css

Si deseas que la ruta sea relativa en vez de absoluta, reemplaza '/odontologia/assets/css/odontologia.css' por 'assets/css/odontologia.css' en los <link>.
